download2.py done
menu.py done
main.py ______can create dir and chane work dir
	  |
	  |___can download image from lh scan (renamed)


                    ################################################
                    #                                              #
                    #                                              #
                    # If get lhscan return forbiden try fetch site #
                    # with browser and try again                   #
                    #                                              #
                    #                                              #
                    ################################################
