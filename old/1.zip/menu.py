# -*- coding: utf-8 -*- 
def menu(title):
    hold=1
    while hold ==1:
        print('Please select '+str(title))
        #get sub directory
        subd=[]
        for i,j,k in os.walk('.'):
            subd=subd+j


        #create menu
        for i in range(len(subd)):
            print(('\t'+str(i+1)+'. '+subd[i]))
        print('\n')
        target=input('Pick a folder Number from the menu (enter n to create New folder) :')
        crn=''
        target2=int(target)
        print(target2,type(target2))
        print(target2-1 in range(len(subd)))
        #Succeed path
        if (target2-1 in range(len(subd))):
            path='./src/'+subd[target2-1]
            print('PATH is set to "',path,'"')
            return path,subd[target2-1]
            hold=0
        #Uncompleted path
        elif target !='n': 
            print('Directory does not exist.')
        crn=str(input('Do you want to create new source directory. (y/n) : '))
        if crn == 'y' :
            newname=str(input('enter new directory name:'))
            if not os.path.exists(newname):
                os.makedirs(newname)
            elif os.path.exists(newname):print('DIR existed')
        else:continue      
