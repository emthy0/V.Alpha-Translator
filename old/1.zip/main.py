# -*- coding: utf-8 -*- 
import os
import cv2
import numpy as np
import tkinter as tk
from PIL import ImageTk, Image, ImageDraw, ImageFont
import pytesseract
from googletrans import Translator
from functools import partial
from os import walk
translator = Translator()
import os
import urllib.request, urllib.error, urllib.parse,http.cookiejar
from bs4 import BeautifulSoup
import re
#local module
from menu import menu
from download2 import src_download
from run import manga_tran

lang=''
while lang.count('')!=4:
    lang_path,lang=menu('lang')
    if lang.count('')!=4:print('Only 3-Char Language code allow')

src_title_path,title=menu('Manga name')
src_chap_path,chap=menu('Chapter')

os.chdir(src_chap_path)
print('Working on ',os.getcwd())
src_download(str(input('Please enter your site url here : ')))
